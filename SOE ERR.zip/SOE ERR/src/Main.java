// importing all....
import java.io.*;
import java.util.*;

public class Main {
    private Map<String, PupilGrade> pupilGradeMap;

    public Main() {
        // creating hashmap for pupilGrade
        pupilGradeMap = new HashMap<>();
    }

    public static void main(String[] args) {
        Main main = new Main();
        try {
            main.readCSVFile("arithmetic_grades.csv");
            main.computeHighestGrade();
            System.out.println("\n#Passes: " + main.countPassedStudents());
            main.savePupilsWhoPassedToFile("arithmetic_passed.csv");

        } catch (InvalidPupilException e) {
            System.out.println("Invalid pupil encountered: " + e.getMessage());
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (NumberFormatException e) {
            System.out.println("Invalid Grade encountered: " + e.getMessage());
        }
    }

    // checking grades and getting the highest grades among Pupil
    public void computeHighestGrade() {
        int highestGrade = Integer.MIN_VALUE;
        for (PupilGrade grade : pupilGradeMap.values()) {
            if (grade.getGrade() > highestGrade) {
                highestGrade = grade.getGrade();
            }
        }

        // printing the highest graded pupil in terminal
        System.out.println("\nStudents with highest grade: ");
        for (PupilGrade grade : pupilGradeMap.values()) {
            if (grade.getGrade() == highestGrade) {
                System.out.println(grade);
            }
        }
    }

    // for-each loop to get number of student passed which have grade >=40
    public int countPassedStudents() {
        int counter = 0;
        for (PupilGrade pupilGrade : pupilGradeMap.values()) {
            if (pupilGrade.getGrade() >= 40) {
                counter = counter + 1;

            }
        }

        // returning the number of passed student
        return counter;
    }

    // saving the record of those pupil who pass in exam on separate file
    public void savePupilsWhoPassedToFile(String fileName) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            List<PupilGrade> passPupil = new ArrayList<>();
            for (PupilGrade grade : pupilGradeMap.values()) {
                if (grade.getGrade() >= 40) {
                    passPupil.add(grade);
                }
            }

            // Sorting the list of pupil who are pass by lastname
            Collections.sort(passPupil, new LastNameOrderSkill());

            for (PupilGrade grade : passPupil) {
                String record = grade.getPupilId() + "," + grade.getPupilName() + "," + grade.getGrade();
                writer.write(record);
                writer.newLine();
            }
            System.out.println("Pupil passed: " + fileName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Reading each record in a file : Handling exceptions / checking data format / updating hashmap
    private void readCSVFile(String s) throws InvalidPupilException, IOException {
        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader(s));
            String line;
            int lineNumber = 0;
            // Skipping header line
            bufferedReader.readLine();
            while ((line = bufferedReader.readLine()) != null) {
                lineNumber++;
                // iterating through each record in a list
                String[] studentRecord = line.split(",");
                // Invalid record format is captured
                if (studentRecord.length != 3) {
                    System.err.println("Invalid data at line " + lineNumber + ": " + line);
                    //a blank line will trip this exception
                    continue;
                }

                int pupilId = lineNumber;
                String pupilName = studentRecord[1];
                int grade;
                try {
                    grade = Integer.parseInt(studentRecord[2]);
                    // Non-integer number exception are handled
                } catch (NumberFormatException e) {
                    System.err.println("Invalid grading format (record skipped): " + line);
                    continue;
                }

                try {
                    PupilGrade pupilGrade = new PupilGrade(pupilId, pupilName, grade);
                    // putting pupilId(Key) and pupilGrade(value) in a hashmap
                    pupilGradeMap.put(String.valueOf(pupilId), pupilGrade);
                } catch (InvalidPupilException | SchoolInvalidGradeException e) {
                    System.out.println(e);
                }
            }
            // Any Input output Exception is handled
        } catch (IOException e) {
            System.err.println("Error reading the file: " + e.getMessage());
        }
    }

}


class PupilGrade {
    private int pupilId;
    private String pupilName;
    private int grade;

    @Override
    public String toString() {
        return "PupilGrade-> {" +
                "Id=" + pupilId +
                ",Name='" + pupilName + '\'' +
                ",Grade=" + grade +
                '}';
    }

    // getter and setters
    public int getPupilId() {
        return pupilId;
    }

    public String getPupilName() {
        return pupilName;
    }

    public int getGrade() {
        return grade;
    }

    public PupilGrade(int pupilId, String pupilName, int grade) throws SchoolInvalidGradeException, InvalidPupilException {
        this.pupilId = pupilId;
        this.pupilName = pupilName;
        this.grade = grade;

        // Checking the range of grade and throwing exception
        if (grade < 0 || grade > 100)
            throw new SchoolInvalidGradeException("Invalid Grade encountered: " + grade);

        // Checking the Name which is not in original file
        if (pupilName.equals("Afnan Ahmed"))
            throw new InvalidPupilException("Invalid pupil encountered: " + pupilName + " is not in a record :/");
    }
}

//  Custom Exception handling
class SchoolInvalidGradeException extends Exception {
    public SchoolInvalidGradeException(String message) {
        super(message);
    }
}

class InvalidPupilException extends Exception {
    public InvalidPupilException(String message) {
        super(message);
    }
}

// comparator: Function ordering the collection of object
class LastNameOrderSkill implements Comparator<PupilGrade> {
    @Override
    public int compare(PupilGrade first, PupilGrade second) {
        String order1 = first.getPupilName().substring(first.getPupilName().lastIndexOf(' ') + 1);
        String order2 = second.getPupilName().substring(second.getPupilName().lastIndexOf(' ') + 1);
        return order1.compareTo(order2);
    }
}